<?php

function login ($username, $password){

    if($password == "mellon"){
    
        session_start ();
        $_SESSION ["username"] = $username;
        header("Location: main.php");
    }
    else{
        echo "<h1>No, sal de aqui</h1>";
   
    }
}
?>