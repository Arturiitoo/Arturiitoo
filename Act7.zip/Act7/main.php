<?php
    require_once("security.php");
    $username = $_SESSION["username"];
?>
<!DOCTYPE>
<html>
    <head>
        <!-- 
        Silverio Cardona Rodríguez
        ICSE 2019 Técnico Superior en Administración de Sistemas Informáticos en red 
        -->
        <title>BIENVENIDO A MORIA</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link href="https://fonts.googleapis.com/css?family=Bilbo&display=swap" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="style/main.css">
    </head>
    <body>
        <center>
            <?php 
                echo "<h1> Hola $username</h1>" ;
                echo "<h2> Disfruta de nuestra pagina web</h2>" ;
            ?>
           <a href = "LogOut.php">salir de aquí</a>
        </center>
    </body>
</html>