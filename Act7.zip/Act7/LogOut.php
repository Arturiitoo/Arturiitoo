<?php
    session_start(); // Se inicia la sesión para acceder a las variables
    session_unset(); // Se desvinculan las variables
    session_destroy(); // Se destruye la sesión
    header("Location: index.php"); // Redireccionamos al index
?>
