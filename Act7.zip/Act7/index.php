<?php
    
    session_start();
    if (isset($_session["username"])){
        header("Location: main.php");
    }

    if(isset($_POST["username"]) && isset ($_POST["password"])){
        require_once("login.php");
        $user = strtolower($_POST["username"]);
        $pass = $_POST["password"];
        echo login($user, $pass);
    } 
?>
<!DOCTYPE>
<html>
    <head>
        <!-- 
        Silverio Cardona Rodríguez
        ICSE 2019 Técnico Superior en Administración de Sistemas Informáticos en red 
        -->
        <title>BIENVENIDO A MORIA</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link href="https://fonts.googleapis.com/css?family=Bilbo&display=swap" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="style/main.css">
    </head>
    <body>
        <center>
            <form method="post" action="index.php">
                <label for="username"> Cual es tu nombre forastero? </label>
                <input name="username" type="text">
                <br>
                <label for="password"> Habla amigo, y entra: </label>
                <input name="password" type="password">
                <br>
                <br>

                <button type="submit" name="submit"> ENVIAR </button>
            </form>
        </center>
    </body>
</html>



